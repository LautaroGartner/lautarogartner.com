# The Real Cost of Your Car

Live: https://carcost.lautarogartner.com

A responsive car loan calculator built with Next.js App Router, TypeScript and Tailwind CSS. Monochrome styling inspired by the supplied Apple reference. All calculations run on the device; no login, data API, analytics or lender quotes.

## Run

Requires Node.js 22.12+ (22 LTS), Node.js 24 LTS, or Node.js 26+.

```sh
npm ci
npm run dev
```

Open http://127.0.0.1:3000. To verify and preview the production export:

```sh
npm test
npm run typecheck
npm run build
npm start
```

The production build exports the complete static site to `out/`, suitable for any static host. `npm start` serves that export locally, so build first. No deployment or cloud resources are required.

## Features

- Editable price, down payment, annual interest rate, 1–120 month term, sales tax and fees.
- Preset: $35,000 price, $5,000 down, 8% annual interest, 60 months, zero tax/fees.
- Monthly payment, amount financed, interest, total loan payments and total purchase cost.
- Side-by-side 36, 48, 60, 72 and 84 month comparisons. Select a term to update the breakdown.
- Pointer and keyboard/touch slider exploration of monthly principal versus interest.
- Full monthly schedule, paginated and downloadable as CSV.
- Inline errors preserve the last valid result with an explicit notice.
- A silver heading shimmer sweeps left to right; reduced-motion and forced-color users get a static heading.
- Native labels, visible keyboard focus, polite announcements, scrollable tables and reduced-motion support.

## Calculation conventions

Sales tax applies to the full car price. All entered fees and taxes are financed. The down payment is subtracted from price + tax + fees. Local taxable bases, trade-in credits and lender fee treatment may differ.

For principal `P`, monthly rate `r = annual interest rate / 100 / 12` and `n` months, the regular payment is `P * r / (1 - (1 + r)^(-n))`. At 0% interest it is `P / n`. The implementation uses `log1p` and `expm1` for stability near 0% interest.

Ledger arithmetic uses integer cents. The regular payment and monthly interest round to cents; the final payment clears the balance. Tiny loans may clear before the selected term due to cent rounding. The preset regular payment is **$608.29**; final payment **$608.41**; interest **$6,497.52**; loan payments **$36,497.52**; purchase cost **$41,497.52**. Unrounded theoretical calculations can differ by a few cents.

- **Total loan payments** = principal + interest, excluding the down payment.
- **Total purchase cost** = total loan payments + down payment, including financed tax and fees.

The entered rate is the fixed annual interest rate, with monthly on-time payments and no extra payments. Actual lender APR can include charges. Estimates exclude insurance, maintenance, depreciation, fuel and other ownership costs. This is an illustrative tool, not a lender offer.

Definitions and term-comparison context follow the [CFPB guide to comparing auto loans](https://www.consumerfinance.gov/ask-cfpb/how-do-i-compare-auto-loan-offers-what-should-i-look-at-besides-the-monthly-payment-en-753/). Setup follows the [Next.js installation guide](https://nextjs.org/docs/app/getting-started/installation).

## Verification

38 unit tests cover the preset annuity, zero interest, one-month repayment, rounding, financed tax/fees, cash purchases, every payment and balance across all five terms, term tradeoffs, invalid inputs, numerical stability and CSV export. The production build also validates TypeScript.


The calculator also estimates a maximum sticker price from a monthly budget, using the current rate, term, down payment, tax and fee assumptions. This is a planning estimate, not affordability advice or loan approval. Canonical metadata, Open Graph previews, robots.txt, sitemap.xml and WebApplication structured data accompany server-rendered buyer guidance. The heading light sweep respects reduced motion and forced colors.

The visible rate label is “Annual interest rate.” The internal `apr` property is retained for source compatibility and represents nominal annual interest, not a lender’s disclosed APR.

Tax-and-fee intent: a second illustrative preset loads 7.5% tax and $450 fees; the original zero-tax preset is unchanged. The result now itemizes tax, fees and price before financing. A public comparison uses the same amortization module to show upfront versus financed costs.

Printing uses a dedicated report containing the selected loan inputs, cost definitions and the complete repayment schedule. Screen pagination does not limit the printed rows. Cash purchases and invalid form entries have explicit report states.
