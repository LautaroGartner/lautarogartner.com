import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "The Real Cost of Your Car — Car Loan Calculator",
  description: "See beyond the monthly payment. Estimate your car loan, compare loan terms, and explore every payment with a clear amortization schedule. No login or lender quotes.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
