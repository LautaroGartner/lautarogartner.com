import type { Metadata } from "next";
import "./globals.css";
const origin = "https://carcost.lautarogartner.com";
export const metadata: Metadata = {
 metadataBase: new URL(origin),
 title: "Car Loan Calculator with Tax & Fees | The Real Cost",
 description: "Free car loan calculator with sales tax and fees. Estimate monthly payments, total interest and purchase cost, compare 36–84 months, and export an amortization schedule.",
 alternates: { canonical: origin },
 applicationName: "The Real Cost of Your Car",
 authors: [{ name: "Lautaro Gärtner", url: "https://www.lautarogartner.com/about" }],
 robots: { index: true, follow: true, googleBot: { index: true, follow: true, "max-image-preview": "large" } },
 openGraph: { type: "website", url: origin, siteName: "The Real Cost of Your Car", locale: "en_US", title: "Car Loan Calculator — See the Real Cost", description: "Compare monthly payments, interest, taxes and fees before you buy. Free, private and no login.", images: [{ url: "/og/car-loan-calculator.jpg", width: 1200, height: 630, alt: "The Real Cost of Your Car calculator with a $35,000 example" }] },
 twitter: { card: "summary_large_image", title: "Car Loan Calculator — The Real Cost", description: "Monthly payments, tax, fees and total interest. Compare five loan terms.", images: ["/og/car-loan-calculator.jpg"] },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
 return <html lang="en"><body>{children}</body></html>;
}
