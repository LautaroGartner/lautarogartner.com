import type { MetadataRoute } from "next";
export const dynamic = "force-static";
export default function sitemap(): MetadataRoute.Sitemap {
 return [{ url: "https://carcost.lautarogartner.com", lastModified: "2026-11-03" }];
}
