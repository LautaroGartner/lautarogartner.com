import { CalculatorGuide } from "@/components/calculator-guide";
import { Calculator } from "@/components/calculator";

function ExternalLinkIcon() {
  return <svg aria-hidden="true" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M7 17 17 7M7 7h10v10" /></svg>;
}

export default function Home() {
  return <>
    <a className="skip-link" href="#calculator">Skip to calculator</a>
    <header className="site-header"><nav className="nav-inner flex items-center justify-between gap-5" aria-label="Main navigation">
      <a href="#" className="wordmark">The Real Cost<span className="wordmark-dot">.</span></a>
      <div className="nav-links flex items-center gap-7"><a href="#calculator">Calculator</a><a href="#compare">Compare</a><a href="#schedule">Schedule</a>
        <a className="portfolio-nav" href="https://www.lautarogartner.com" target="_blank" rel="noopener noreferrer">Lautaro Gartner<ExternalLinkIcon /><span className="sr-only"> (opens in a new tab)</span></a>
      </div>
    </nav></header>
    <main className="page-container">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({"@context":"https://schema.org","@type":"WebApplication","@id":"https://carcost.lautarogartner.com/#calculator",inLanguage:"en",softwareHelp:"https://www.lautarogartner.com/car-loan-calculator-guide",subjectOf:{"@type":"Article",url:"https://www.lautarogartner.com/car-loan-calculator-guide",name:"Car loan calculator guide: payments, tax & fees"},name:"The Real Cost of Your Car",url:"https://carcost.lautarogartner.com",description:"Free car loan calculator with tax, fees, monthly payments, five loan terms and an amortization schedule.",applicationCategory:"FinanceApplication",operatingSystem:"Any",browserRequirements:"JavaScript enabled for interactive calculations",isAccessibleForFree:true,offers:{"@type":"Offer",price:"0",priceCurrency:"USD"},creator:{"@type":"Person","@id":"https://www.lautarogartner.com/#person",name:"Lautaro Gärtner",url:"https://www.lautarogartner.com/about"},featureList:["Monthly car payments with tax and fees","36, 48, 60, 72 and 84 month comparisons","Monthly budget to car price estimate","Principal versus interest chart","Amortization schedule and CSV export"],image:"https://carcost.lautarogartner.com/og/car-loan-calculator.jpg"}) }} />
      <div className="hero"><p className="hero-eyebrow">Free car loan calculator</p><h1><span className="hero-title-shimmer">The real cost<br className="mobile-break" /> of your car.</span></h1><p>Estimate your monthly car payment.<br className="mobile-break" /> See the interest, tax and fees, too.</p></div>
      <Calculator />
      <CalculatorGuide />
    </main>
    <footer className="site-footer page-container flex flex-wrap items-center justify-between gap-4"><span>The Real Cost of Your Car</span><span>Calculated on your device. Your numbers stay yours.</span>
      <a className="creator-link" href="https://www.lautarogartner.com" target="_blank" rel="noopener noreferrer"><span>Built by</span> Lautaro Gartner<ExternalLinkIcon /><span className="sr-only"> (opens in a new tab)</span></a>
    </footer>
  </>;
}
