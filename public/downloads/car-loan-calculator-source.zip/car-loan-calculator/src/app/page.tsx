import { Calculator } from "@/components/calculator";

function ExternalLinkIcon() {
  return <svg aria-hidden="true" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M7 17 17 7M7 7h10v10" /></svg>;
}

export default function Home() {
  return <>
    <a className="skip-link" href="#calculator">Skip to calculator</a>
    <header className="site-header"><nav className="nav-inner flex items-center justify-between gap-5" aria-label="Main navigation">
      <a href="#" className="wordmark">The Real Cost<span className="wordmark-dot">.</span></a>
      <div className="nav-links flex items-center gap-7"><a href="#calculator">Calculator</a><a href="#compare">Compare</a><a href="#schedule">Schedule</a>
        <a className="portfolio-nav" href="https://www.lautarogartner.com" target="_blank" rel="noopener noreferrer">Lautaro Gartner<ExternalLinkIcon /><span className="sr-only"> (opens in a new tab)</span></a>
      </div>
    </nav></header>
    <main className="page-container">
      <div className="hero"><h1>The real cost<br className="mobile-break" /> of your car.</h1><p>Look beyond the sticker price.<br className="mobile-break" /> See the whole picture.</p></div>
      <Calculator />
    </main>
    <footer className="site-footer page-container flex flex-wrap items-center justify-between gap-4"><span>The Real Cost of Your Car</span><span>Calculated on your device. Your numbers stay yours.</span>
      <a className="creator-link" href="https://www.lautarogartner.com" target="_blank" rel="noopener noreferrer"><span>Built by</span> Lautaro Gartner<ExternalLinkIcon /><span className="sr-only"> (opens in a new tab)</span></a>
    </footer>
  </>;
}
