import { PDFDocument, StandardFonts, rgb, PageSizes } from "pdf-lib";
import { money, type LoanInput, type LoanResult } from "./loan";

/** Generate a complete, selectable-text report locally, independent of screen pagination. */
export async function createLoanPDF(input: LoanInput, result: LoanResult, invalid = false) {
  const pdf = await PDFDocument.create();
  pdf.setTitle("The Real Cost of Your Car - Loan estimate");
  pdf.setAuthor("The Real Cost of Your Car");
  pdf.setSubject("Estimated purchase costs and complete monthly amortization schedule");
  const regular = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const ink = rgb(0.11, 0.12, 0.14), muted = rgb(0.36, 0.38, 0.41), blue = rgb(0.02, 0.36, 0.72);
  const margin = 42, width = PageSizes.A4[0] - margin * 2;
  let page = pdf.addPage(PageSizes.A4), y = 0;
  const text = (value: string, x: number, top: number, size = 10, strong = false, color = ink) =>
    page.drawText(value, { x, y: page.getHeight() - top - size, size, font: strong ? bold : regular, color });
  const line = (top: number) => page.drawLine({ start: { x: margin, y: page.getHeight() - top }, end: { x: margin + width, y: page.getHeight() - top }, color: rgb(0.86, 0.88, 0.90), thickness: 0.5 });
  const paragraph = (value: string, size = 9, color = muted) => {
    let current = "";
    for (const word of value.split(" ")) {
      if (regular.widthOfTextAtSize(`${current} ${word}`.trim(), size) > width && current) {
        text(current, margin, y, size, false, color); y += size + 4; current = word;
      } else current = `${current} ${word}`.trim();
    }
    if (current) { text(current, margin, y, size, false, color); y += size + 4; }
  };
  text("THE REAL COST OF YOUR CAR", margin, 40, 9, true, blue);
  text("Your car loan report.", margin, 64, 27, true);
  text(`${input.months} months  /  US dollars  /  Fixed annual interest rate`, margin, 104, 10, false, muted);
  y = 134;
  if (invalid) { paragraph("LAST VALID ESTIMATE: Some calculator entries need correction. This report uses the valid inputs below, matching the last valid estimate on screen.", 9, ink); y += 10; }
  const items: [string, string][] = [
    ["Car price", money(input.price)], ["Down payment", money(input.downPayment)],
    ["Annual interest rate", `${input.apr}%`], ["Loan term", `${input.months} months`],
    [`Sales tax (${input.salesTax}%)`, money(result.taxAmount)], ["Purchase fees", money(input.fees)],
    ["Tax and fees paid", input.financeCosts === 1 ? "Within loan" : "Upfront"],
    ["Price + tax + fees", money(result.purchaseSubtotal)],
    ["Cash at purchase", money(input.downPayment + result.upfrontCosts)], ["Amount financed", money(result.amountFinanced)],
    ["Regular monthly payment", money(result.monthlyPayment)], ["Total interest", money(result.totalInterest)],
    ["Total loan payments", money(result.totalLoanPayments)], ["Total purchase cost", money(result.totalPurchaseCost)],
  ];
  for (const [label, value] of items) {
    const strong = ["Regular monthly payment", "Total loan payments", "Total purchase cost"].includes(label);
    text(label, margin, y, 10, strong);
    text(value, margin + width - (strong ? bold : regular).widthOfTextAtSize(value, 10), y, 10, strong);
    y += 22; line(y - 5);
  }
  y += 14;
  text("Understand your estimate", margin, y, 12, true); y += 22;
  paragraph("Total loan payments include principal and interest only. Total purchase cost adds the down payment and any tax and fees paid upfront. It excludes insurance, maintenance, depreciation, fuel and other ownership costs.");
  y += 8;
  paragraph("Tax applies to the full car price, excluding fees. The annual interest rate is divided by 12; lender APR disclosures may include fees and differ from this rate. Interest is rounded monthly and the final payment clears the balance. Actual lender timing, rounding and tax rules may differ. This is an illustrative estimate, not a lender offer.");
  const tableHeader = () => {
    text("Complete payment schedule", margin, y, 16, true); y += 28;
    text(`${result.schedule.length} payments  /  Final payment: ${money(result.schedule.at(-1)?.payment ?? 0)}`, margin, y, 9, false, muted); y += 24;
    page.drawRectangle({ x: margin, y: page.getHeight() - y - 26, width, height: 26, color: rgb(0.94, 0.95, 0.97) });
    ["Month", "Payment", "Principal", "Interest", "Balance"].forEach((label, i) => text(label, margin + [8, 80, 182, 284, 386][i], y + 8, 9, true));
    y += 30;
  };
  if (result.schedule.length) {
    page = pdf.addPage(PageSizes.A4); y = 42; tableHeader();
    const row = (values: string[], strong = false) => {
      if (y > page.getHeight() - 88) { page = pdf.addPage(PageSizes.A4); y = 42; tableHeader(); }
      values.forEach((value, i) => text(value, margin + [8, 80, 182, 284, 386][i], y + 5, 9, strong));
      y += 20; line(y);
    };
    for (const payment of result.schedule) row([String(payment.month), money(payment.payment), money(payment.principal), money(payment.interest), money(payment.balance)]);
    row(["Totals", money(result.totalLoanPayments), money(result.amountFinanced), money(result.totalInterest), money(0)], true);
  } else { y += 12; paragraph("No loan is required. The upfront payment covers the purchase, so there are no monthly repayments.", 10, ink); }
  const pages = pdf.getPages();
  pages.forEach((p, i) => {
    page = p;
    line(p.getHeight() - 39);
    text("carcost.lautarogartner.com  /  Calculated on your device", margin, p.getHeight() - 29, 8, false, muted);
    text(`${i + 1} / ${pages.length}`, margin + width - 28, p.getHeight() - 29, 8, false, muted);
  });
  return pdf.save();
}
