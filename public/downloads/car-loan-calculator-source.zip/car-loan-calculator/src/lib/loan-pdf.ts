import { PDFDocument, StandardFonts, rgb, PageSizes } from "pdf-lib";
import { calculateLoan, TERMS, money, type LoanInput, type LoanResult } from "./loan";

/** Generate a complete, selectable-text report locally, independent of screen pagination. */
export async function createLoanPDF(input: LoanInput, result: LoanResult, invalid = false) {
  const pdf = await PDFDocument.create();
  pdf.setTitle("The Real Cost of Your Car - Loan estimate");
  pdf.setAuthor("The Real Cost of Your Car");
  pdf.setSubject("Estimated purchase costs, payment chart, loan term comparisons and complete monthly amortization schedule");
  const regular = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const ink = rgb(0.11, 0.12, 0.14), muted = rgb(0.36, 0.38, 0.41), blue = rgb(0.02, 0.36, 0.72);
  const margin = 42, width = PageSizes.A4[0] - margin * 2;
  let page = pdf.addPage(PageSizes.A4), y = 0;
  const text = (value: string, x: number, top: number, size = 10, strong = false, color = ink) =>
    page.drawText(value, { x, y: page.getHeight() - top - size, size, font: strong ? bold : regular, color });
  const line = (top: number) => page.drawLine({ start: { x: margin, y: page.getHeight() - top }, end: { x: margin + width, y: page.getHeight() - top }, color: rgb(0.86, 0.88, 0.90), thickness: 0.5 });
  const paragraph = (value: string, size = 9, color = muted) => {
    let current = "";
    for (const word of value.split(" ")) {
      if (regular.widthOfTextAtSize(`${current} ${word}`.trim(), size) > width && current) {
        text(current, margin, y, size, false, color); y += size + 4; current = word;
      } else current = `${current} ${word}`.trim();
    }
    if (current) { text(current, margin, y, size, false, color); y += size + 4; }
  };
  text("THE REAL COST OF YOUR CAR", margin, 40, 9, true, blue);
  text("Your car loan report.", margin, 64, 27, true);
  text(`${input.months} months  /  US dollars  /  Fixed annual interest rate`, margin, 104, 10, false, muted);
  y = 134;
  if (invalid) { paragraph("LAST VALID ESTIMATE: Some calculator entries need correction. This report uses the valid inputs below, matching the last valid estimate on screen.", 9, ink); y += 10; }
  const items: [string, string][] = [
    ["Car price", money(input.price)], ["Down payment", money(input.downPayment)],
    ["Annual interest rate", `${input.apr}%`], ["Loan term", `${input.months} months`],
    [`Sales tax (${input.salesTax}%)`, money(result.taxAmount)], ["Purchase fees", money(input.fees)],
    ["Tax and fees paid", input.financeCosts === 1 ? "Within loan" : "Upfront"],
    ["Price + tax + fees", money(result.purchaseSubtotal)],
    ["Cash at purchase", money(input.downPayment + result.upfrontCosts)], ["Amount financed", money(result.amountFinanced)],
    ["Regular monthly payment", money(result.monthlyPayment)], ["Total interest", money(result.totalInterest)],
    ["Total loan payments", money(result.totalLoanPayments)], ["Total purchase cost", money(result.totalPurchaseCost)],
  ];
  for (const [label, value] of items) {
    const strong = ["Regular monthly payment", "Total loan payments", "Total purchase cost"].includes(label);
    text(label, margin, y, 10, strong);
    text(value, margin + width - (strong ? bold : regular).widthOfTextAtSize(value, 10), y, 10, strong);
    y += 22; line(y - 5);
  }
  y += 14;
  text("Understand your estimate", margin, y, 12, true); y += 22;
  paragraph("Total loan payments include principal and interest only. Total purchase cost adds the down payment and any tax and fees paid upfront. It excludes insurance, maintenance, depreciation, fuel and other ownership costs.");
  y += 8;
  paragraph("Tax applies to the full car price, excluding fees. The annual interest rate is divided by 12; lender APR disclosures may include fees and differ from this rate. Interest is rounded monthly and the final payment clears the balance. Actual lender timing, rounding and tax rules may differ. This is an illustrative estimate, not a lender offer.");
  // A dedicated analysis page keeps the chart and all five comparisons legible on paper.
  page = pdf.addPage(PageSizes.A4);
  text("Every payment. Broken down.", margin, 42, 22, true);
  text(`${input.months}-month selected loan / Principal versus interest / US dollars`, margin, 77, 10, false, muted);
  const principalColor = blue, interestColor = rgb(0.56, 0.59, 0.64);
  const swatch = (label: string, x: number, color: ReturnType<typeof rgb>) => {
    page.drawRectangle({ x, y: page.getHeight() - 116, width: 9, height: 9, color });
    text(label, x + 15, 106, 9, false, muted);
  };
  swatch("Principal", margin, principalColor); swatch("Interest", margin + 90, interestColor);
  const plotX = margin + 57, plotWidth = width - 57, plotTop = 143, plotHeight = 160;
  const ceiling = Math.max(result.monthlyPayment, ...result.schedule.map(row => row.payment), 1);
  const axisMoney = (value: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(value);
  if (result.schedule.length) {
    for (const fraction of [0, 0.5, 1]) {
      const top = plotTop + plotHeight * (1 - fraction);
      text(axisMoney(ceiling * fraction), margin, top - 5, 8, false, muted);
      page.drawLine({ start: { x: plotX, y: page.getHeight() - top }, end: { x: margin + width, y: page.getHeight() - top }, thickness: 0.5, color: rgb(0.86, 0.88, 0.90) });
    }
    const barWidth = plotWidth / result.schedule.length;
    for (const [index, row] of result.schedule.entries()) {
      const principalHeight = row.principal / ceiling * plotHeight;
      const interestHeight = row.interest / ceiling * plotHeight;
      const x = plotX + index * barWidth + barWidth * 0.12;
      const bottom = page.getHeight() - plotTop - plotHeight;
      page.drawRectangle({ x, y: bottom, width: barWidth * 0.76, height: principalHeight, color: principalColor });
      page.drawRectangle({ x, y: bottom + principalHeight, width: barWidth * 0.76, height: interestHeight, color: interestColor });
    }
    const labels = [...new Set([1, Math.ceil(result.schedule.length / 2), result.schedule.length])];
    labels.forEach(month => {
      const label = `Month ${month}`;
      const center = plotX + (month - 0.5) * barWidth;
      const x = Math.max(plotX, Math.min(margin + width - regular.widthOfTextAtSize(label, 8), center - regular.widthOfTextAtSize(label, 8) / 2));
      text(label, x, 315, 8, false, muted);
    });
    y = 346;
    paragraph(`Over ${input.months} months: ${money(result.amountFinanced)} in principal and ${money(result.totalInterest)} in interest. Each stacked bar represents one payment; the full schedule lists the exact amounts.`);
  } else {
    y = 180; paragraph("No loan is required, so there are no monthly principal or interest payments to chart.", 11, ink);
  }
  text("Find your balance.", margin, 405, 22, true);
  y = 442;
  paragraph("Compare the same car price, down payment, annual interest rate, tax and fees across five terms. Only the number of months changes. Actual lenders may offer different rates by term.");
  const labelWidth = 143, columnWidth = (width - labelWidth) / TERMS.length, tableTop = 487;
  page.drawRectangle({ x: margin, y: page.getHeight() - tableTop - 40, width, height: 40, color: rgb(0.94, 0.95, 0.97) });
  text("Loan term", margin + 8, tableTop + 11, 9, true);
  TERMS.forEach((months, i) => {
    const x = margin + labelWidth + i * columnWidth;
    text(`${months} months`, x + 4, tableTop + 7, 9, true);
    if (input.months === months) text("Selected", x + 4, tableTop + 22, 8, false, blue);
  });
  const comparisons = TERMS.map(months => calculateLoan({ ...input, months }));
  const metrics = [
    ["Monthly payment", "monthlyPayment"], ["Total interest", "totalInterest"],
    ["Total loan payments", "totalLoanPayments"], ["Total purchase cost", "totalPurchaseCost"],
  ] as const;
  metrics.forEach(([label, key], index) => {
    const top = tableTop + 40 + index * 36;
    text(label, margin + 8, top + 12, 9, key === "totalPurchaseCost");
    comparisons.forEach((loan, i) => {
      const value = money(loan[key]);
      // Keep even maximum supported dollar amounts inside their comparison column.
      const size = Math.min(9, (columnWidth - 8) / regular.widthOfTextAtSize(value, 1));
      text(value, margin + labelWidth + i * columnWidth + 4, top + 12, size);
    });
    line(top + 36);
  });
  y = tableTop + 40 + metrics.length * 36 + 20;
  paragraph("Total purchase cost includes your down payment and any tax and fees paid upfront. Insurance, maintenance, depreciation, fuel and other ownership costs are excluded. Longer terms can reduce the monthly payment while increasing total interest.");
  if (!TERMS.some(months => months === input.months)) {
    y += 8; paragraph(`Your selected ${input.months}-month term is shown in the report summary, chart and full payment schedule. The comparison above shows the five standard terms.`);
  }
  const tableHeader = () => {
    text("Complete payment schedule", margin, y, 16, true); y += 28;
    text(`${result.schedule.length} payments  /  Final payment: ${money(result.schedule.at(-1)?.payment ?? 0)}`, margin, y, 9, false, muted); y += 24;
    page.drawRectangle({ x: margin, y: page.getHeight() - y - 26, width, height: 26, color: rgb(0.94, 0.95, 0.97) });
    ["Month", "Payment", "Principal", "Interest", "Balance"].forEach((label, i) => text(label, margin + [8, 80, 182, 284, 386][i], y + 8, 9, true));
    y += 30;
  };
  if (result.schedule.length) {
    page = pdf.addPage(PageSizes.A4); y = 42; tableHeader();
    const row = (values: string[], strong = false) => {
      if (y > page.getHeight() - 88) { page = pdf.addPage(PageSizes.A4); y = 42; tableHeader(); }
      values.forEach((value, i) => text(value, margin + [8, 80, 182, 284, 386][i], y + 5, 9, strong));
      y += 20; line(y);
    };
    for (const payment of result.schedule) row([String(payment.month), money(payment.payment), money(payment.principal), money(payment.interest), money(payment.balance)]);
    row(["Totals", money(result.totalLoanPayments), money(result.amountFinanced), money(result.totalInterest), money(0)], true);
  }
  const pages = pdf.getPages();
  pages.forEach((p, i) => {
    page = p;
    line(p.getHeight() - 39);
    text("carcost.lautarogartner.com  /  Calculated on your device", margin, p.getHeight() - 29, 8, false, muted);
    text(`${i + 1} / ${pages.length}`, margin + width - 28, p.getHeight() - 29, 8, false, muted);
  });
  return pdf.save();
}
