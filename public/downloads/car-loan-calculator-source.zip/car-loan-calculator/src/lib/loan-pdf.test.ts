import { describe, expect, it } from "vitest";
import { PDFDocument } from "pdf-lib";
import { createLoanPDF } from "./loan-pdf";
import { calculateLoan, EXAMPLE } from "./loan";

describe("downloadable loan report", () => {
  it.each([60, 84, 120])("creates a complete paginated %i-month PDF", async months => {
    const input = { ...EXAMPLE, months };
    const bytes = await createLoanPDF(input, calculateLoan(input));
    const pdf = await PDFDocument.load(bytes);
    expect(pdf.getTitle()).toContain("Loan estimate");
    expect(pdf.getPageCount()).toBe(2 + Math.ceil((months + 1) / 32));
  });
  it("creates a cash purchase report with comparisons and no repayment pages", async () => {
    const input = { ...EXAMPLE, downPayment: 35000 };
    const pdf = await PDFDocument.load(await createLoanPDF(input, calculateLoan(input)));
    expect(pdf.getPageCount()).toBe(2);
  });
});
