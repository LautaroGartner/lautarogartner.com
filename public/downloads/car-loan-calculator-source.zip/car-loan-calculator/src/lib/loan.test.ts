import { describe, expect, it } from "vitest";
import { calculateLoan, EXAMPLE, scheduleCSV, TERMS, validateLoan } from "./loan";

describe("fixed-rate car loan amortization", () => {
  it("matches the illustrative $35,000 / $5,000 down / 8% / 60-month example", () => {
    const loan = calculateLoan(EXAMPLE);
    // Independent standard annuity formula, rounded to a monthly cent.
    const r = .08 / 12;
    const expected = 30_000 * r * (1 + r) ** 60 / ((1 + r) ** 60 - 1);
    expect(loan.monthlyPayment).toBeCloseTo(expected, 2);
    expect(loan.monthlyPayment).toBe(608.29);
    expect(loan.amountFinanced).toBe(30_000);
    expect(loan.totalInterest).toBe(6497.52);
    expect(loan.totalLoanPayments).toBe(36497.52);
    expect(loan.totalPurchaseCost).toBe(41497.52);
    expect(loan.schedule[0]).toEqual({ month: 1, payment: 608.29, principal: 408.29, interest: 200, balance: 29591.71 });
    expect(loan.schedule.at(-1)?.payment).toBe(608.41);
    expect(loan.schedule.at(-1)?.balance).toBe(0);
  });

  it("handles zero interest and adjusts a fractional final cent", () => {
    const loan = calculateLoan({ ...EXAMPLE, price: 100, downPayment: 0, apr: 0, months: 3 });
    expect(loan.monthlyPayment).toBe(33.33);
    expect(loan.totalInterest).toBe(0);
    expect(loan.totalLoanPayments).toBe(100);
    expect(loan.schedule.map(p => p.payment)).toEqual([33.33, 33.33, 33.34]);
  });

  it("finances taxes on the full price plus fees, after the down payment", () => {
    const loan = calculateLoan({ ...EXAMPLE, salesTax: 7.5, fees: 450 });
    expect(loan.taxAmount).toBe(2625);
    expect(loan.purchaseSubtotal).toBe(38075);
    expect(loan.amountFinanced).toBe(33075);
    expect(loan.totalPurchaseCost).toBeCloseTo(38075 + loan.totalInterest, 8);
    expect(loan.totalPurchaseCost - loan.totalLoanPayments).toBeCloseTo(5000, 8);
  });

  it("returns zero borrowing costs for a cash purchase", () => {
    const loan = calculateLoan({ ...EXAMPLE, downPayment: 35_000 });
    expect(loan.amountFinanced).toBe(0);
    expect(loan.monthlyPayment).toBe(0);
    expect(loan.totalInterest).toBe(0);
    expect(loan.totalLoanPayments).toBe(0);
    expect(loan.totalPurchaseCost).toBe(35000);
    expect(loan.schedule).toEqual([]);
  });

  it("handles a one-month loan", () => {
    const loan = calculateLoan({ ...EXAMPLE, months: 1 });
    expect(loan.monthlyPayment).toBe(30200);
    expect(loan.totalInterest).toBe(200);
    expect(loan.schedule[0].balance).toBe(0);
  });

  it.each(TERMS)("reconciles every payment and balance for %i months", months => {
    const loan = calculateLoan({ ...EXAMPLE, months });
    let balance = loan.amountFinanced;
    for (const row of loan.schedule) {
      expect(row.payment).toBeCloseTo(row.principal + row.interest, 8);
      expect(row.balance).toBeCloseTo(balance - row.principal, 8);
      expect(row.balance).toBeGreaterThanOrEqual(0);
      balance = row.balance;
    }
    expect(loan.schedule).toHaveLength(months);
    expect(balance).toBe(0);
    expect(loan.schedule.reduce((sum, row) => sum + row.principal, 0)).toBeCloseTo(loan.amountFinanced, 8);
    expect(loan.schedule.reduce((sum, row) => sum + row.payment, 0)).toBeCloseTo(loan.totalLoanPayments, 8);
    expect(loan.schedule.reduce((sum, row) => sum + row.interest, 0)).toBeCloseTo(loan.totalInterest, 8);
  });

  it("shows decreasing payments and increasing interest across longer terms", () => {
    const loans = TERMS.map(months => calculateLoan({ ...EXAMPLE, months }));
    for (let i = 1; i < loans.length; i++) {
      expect(loans[i].monthlyPayment).toBeLessThan(loans[i - 1].monthlyPayment);
      expect(loans[i].totalInterest).toBeGreaterThan(loans[i - 1].totalInterest);
    }
  });

  it.each([
    { price: -1 }, { price: NaN }, { apr: Infinity }, { apr: -1 }, { apr: 101 },
    { salesTax: -1 }, { fees: -1 }, { months: 0 }, { months: 2.5 }, { months: 121 },
    { downPayment: 35000.01 }, { price: 35000.001 }, { price: 10000001 },
  ])("rejects invalid input %o", patch => {
    expect(() => calculateLoan({ ...EXAMPLE, ...patch })).toThrow(RangeError);
    expect(Object.keys(validateLoan({ ...EXAMPLE, ...patch })).length).toBeGreaterThan(0);
  });

  it("handles tiny positive APR without numerical instability", () => {
    const loan = calculateLoan({ ...EXAMPLE, apr: 1e-10 });
    expect(loan.monthlyPayment).toBe(500);
    expect(loan.totalInterest).toBe(0);
    expect(loan.schedule.at(-1)?.balance).toBe(0);
  });

  it("handles very small loans without negative balances", () => {
    const loan = calculateLoan({ ...EXAMPLE, price: .01, downPayment: 0, months: 120 });
    expect(loan.totalLoanPayments).toBe(.01);
    expect(loan.schedule.at(-1)?.balance).toBe(0);
  });

  it("exports the entire schedule as numeric USD CSV", () => {
    const loan = calculateLoan(EXAMPLE);
    const lines = scheduleCSV(loan.schedule).split("\r\n");
    expect(lines).toHaveLength(61);
    expect(lines[1]).toBe("1,608.29,408.29,200.00,29591.71");
    expect(lines[60]).toMatch(/^60,608.41,604.38,4.03,0.00$/);
  });
});

describe("upfront purchase costs", () => {
  it("keeps taxes and fees outside the loan without losing them from purchase cost", () => {
    const financed = calculateLoan({ ...EXAMPLE, salesTax: 7.5, fees: 450 });
    const upfront = calculateLoan({ ...EXAMPLE, salesTax: 7.5, fees: 450, financeCosts: 0 });
    expect(upfront.amountFinanced).toBe(30000);
    expect(upfront.upfrontCosts).toBe(3075);
    expect(upfront.monthlyPayment).toBe(608.29);
    expect(upfront.totalPurchaseCost).toBe(44572.52);
    expect(upfront.totalPurchaseCost).toBeCloseTo(upfront.totalLoanPayments + 5000 + 3075, 8);
    expect(upfront.totalInterest).toBeLessThan(financed.totalInterest);
  });
  it("rejects a down payment beyond the car price when costs are upfront", () => {
    expect(validateLoan({ ...EXAMPLE, salesTax: 10, financeCosts: 0, downPayment: 36000 }).downPayment).toBeTruthy();
    expect(validateLoan({ ...EXAMPLE, financeCosts: .5 }).financeCosts).toBeTruthy();
  });
});
