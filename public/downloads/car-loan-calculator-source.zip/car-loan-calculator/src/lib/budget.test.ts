import { describe, expect, it } from "vitest";
import { calculateLoan, EXAMPLE, priceForBudget } from "./loan";
describe("monthly budget to vehicle price", () => {
  it("handles a zero-interest budget independently", () => {
    expect(priceForBudget(500,{...EXAMPLE,apr:0,months:60,downPayment:5000,salesTax:10,fees:1000})).toBe(30909.09);
  });
  it("finds a sticker price whose estimated payment fits the budget", () => {
    const price=priceForBudget(600,{...EXAMPLE,salesTax:7.5,fees:450});
    expect(price).toBeGreaterThan(30000);
    expect(calculateLoan({...EXAMPLE,salesTax:7.5,fees:450,price}).monthlyPayment).toBeCloseTo(600,2);
  });
  it("does not finance costs when upfront is selected", () => {
    expect(priceForBudget(500,{...EXAMPLE,apr:0,months:60,salesTax:10,fees:1000,financeCosts:0})).toBe(35000);
  });
  it("does not return a negative price or accept an invalid budget", () => {
    expect(priceForBudget(0,{...EXAMPLE,downPayment:0,fees:1000})).toBe(0);
    expect(()=>priceForBudget(NaN,EXAMPLE)).toThrow(RangeError);
    expect(()=>priceForBudget(-1,EXAMPLE)).toThrow(RangeError);
  });
});
