export const TERMS = [36, 48, 60, 72, 84] as const;

export interface LoanInput {
  price: number;
  downPayment: number;
  apr: number;
  months: number;
  salesTax: number;
  fees: number;
}

export const EXAMPLE: LoanInput = {
  price: 35_000, downPayment: 5_000, apr: 8, months: 60, salesTax: 0, fees: 0,
};

export type LoanErrors = Partial<Record<keyof LoanInput, string>>;

export interface Payment {
  month: number;
  payment: number;
  principal: number;
  interest: number;
  balance: number;
}

export interface LoanResult {
  amountFinanced: number;
  taxAmount: number;
  purchaseSubtotal: number;
  monthlyPayment: number;
  totalInterest: number;
  totalLoanPayments: number;
  totalPurchaseCost: number;
  schedule: Payment[];
}

const cents = (value: number) => Math.round((value + Number.EPSILON) * 100);

export function validateLoan(input: LoanInput): LoanErrors {
  const errors: LoanErrors = {};
  const limits: Record<keyof LoanInput, number> = {
    price: 10_000_000, downPayment: 30_000_000, apr: 100, months: 120,
    salesTax: 100, fees: 10_000_000,
  };
  for (const key of Object.keys(limits) as (keyof LoanInput)[]) {
    const value = input[key];
    if (!Number.isFinite(value)) errors[key] = "Enter a number.";
    else if (value < 0) errors[key] = "Enter zero or more.";
    else if (value > limits[key]) errors[key] = `Enter ${limits[key].toLocaleString("en-US")} or less.`;
  }
  for (const key of ["price", "downPayment", "fees"] as const) {
    if (!errors[key] && Math.abs(input[key] * 100 - cents(input[key])) > 0.00001)
      errors[key] = "Use at most 2 decimal places.";
  }
  if (!errors.months && (!Number.isInteger(input.months) || input.months < 1))
    errors.months = "Enter a whole number from 1 to 120.";
  if (!errors.price && !errors.salesTax && !errors.fees && !errors.downPayment) {
    const subtotal = cents(input.price) + Math.round(cents(input.price) * input.salesTax / 100) + cents(input.fees);
    if (cents(input.downPayment) > subtotal)
      errors.downPayment = "Down payment cannot exceed the price, tax and fees combined.";
  }
  return errors;
}

/** Fixed-rate, monthly amortization. Ledger values are rounded to cents each month.
 * APR is used as the nominal annual rate; taxes apply to the full vehicle price.
 * All taxes and fees are financed. The final payment clears rounding residuals.
 */
export function calculateLoan(input: LoanInput): LoanResult {
  const errors = validateLoan(input);
  if (Object.keys(errors).length) throw new RangeError(Object.values(errors).join(" "));

  const taxCents = Math.round(cents(input.price) * input.salesTax / 100);
  const subtotalCents = cents(input.price) + taxCents + cents(input.fees);
  const financedCents = subtotalCents - cents(input.downPayment);
  const rate = input.apr / 1200;
  const exactPayment = rate === 0
    ? financedCents / input.months
    : financedCents * rate / -Math.expm1(-input.months * Math.log1p(rate));
  const regularCents = financedCents === 0 ? 0 : Math.max(1, Math.round(exactPayment));
  let balanceCents = financedCents;
  let interestTotal = 0;
  let paymentTotal = 0;
  const schedule: Payment[] = [];

  for (let month = 1; month <= input.months && balanceCents > 0; month++) {
    const interestCents = Math.round(balanceCents * rate);
    const paymentCents = month === input.months
      ? balanceCents + interestCents
      : Math.min(regularCents, balanceCents + interestCents);
    const principalCents = paymentCents - interestCents;
    balanceCents -= principalCents;
    interestTotal += interestCents;
    paymentTotal += paymentCents;
    schedule.push({ month, payment: paymentCents / 100, principal: principalCents / 100,
      interest: interestCents / 100, balance: balanceCents / 100 });
  }

  return {
    amountFinanced: financedCents / 100,
    taxAmount: taxCents / 100,
    purchaseSubtotal: subtotalCents / 100,
    monthlyPayment: regularCents / 100,
    totalInterest: interestTotal / 100,
    totalLoanPayments: paymentTotal / 100,
    totalPurchaseCost: (paymentTotal + cents(input.downPayment)) / 100,
    schedule,
  };
}

export const money = (value: number) => new Intl.NumberFormat("en-US", {
  style: "currency", currency: "USD", minimumFractionDigits: 2, maximumFractionDigits: 2,
}).format(value);

export function scheduleCSV(schedule: Payment[]): string {
  return ["Month,Payment,Principal,Interest,Remaining balance",
    ...schedule.map(row => [row.month, ...[row.payment, row.principal, row.interest, row.balance].map(n => n.toFixed(2))].join(",")),
  ].join("\r\n");
}
