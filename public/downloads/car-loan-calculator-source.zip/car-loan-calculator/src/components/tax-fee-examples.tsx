import { calculateLoan, EXAMPLE, TAX_FEES_EXAMPLE, money } from "@/lib/loan";

export function TaxFeeExamples() {
 const cases = [
  { name: "No tax or fees", input: EXAMPLE },
  { name: "Tax & fees financed", input: TAX_FEES_EXAMPLE },
  { name: "Tax & fees paid upfront", input: { ...TAX_FEES_EXAMPLE, financeCosts: 0 } },
 ].map(item=>({...item, result: calculateLoan(item.input)}));
 const addedInterest=cases[1].result.totalInterest-cases[2].result.totalInterest;
 return <section className="tax-fee-examples" aria-labelledby="tax-fee-title">
  <h3 id="tax-fee-title">How much do tax and fees add to a car payment?</h3>
  <p>For a $35,000 car with $5,000 down at 8% annual interest over 60 months, adding 7.5% sales tax and $450 in fees raises the estimated payment from <strong>$608.29 to $670.64</strong> when financed. Paying those costs upfront keeps the loan payment at $608.29 and requires $3,075 more cash at purchase.</p>
  <div className="table-scroll" role="region" aria-label="Compare tax and fee financing examples" tabIndex={0}><table className="tax-example-table"><caption>Illustrative scenarios: same $35,000 car, $5,000 down, 8% annual interest and 60 months.</caption><thead><tr><th scope="col">Scenario</th><th scope="col">Cash at purchase</th><th scope="col">Monthly payment</th><th scope="col">Total interest</th><th scope="col">Total purchase cost</th></tr></thead><tbody>{cases.map(item=><tr key={item.name}><th scope="row">{item.name}</th><td>{money(item.input.downPayment+item.result.upfrontCosts)}</td><td>{money(item.result.monthlyPayment)}</td><td>{money(item.result.totalInterest)}</td><td>{money(item.result.totalPurchaseCost)}</td></tr>)}</tbody></table></div>
  <p>Financing the $3,075 of tax and fees adds <strong>{money(addedInterest)} in interest</strong> in this example. Rates and taxes are illustrative. Figures use monthly cent rounding and an adjusted final payment.</p>
  <div className="guide-columns tax-fee-checklist"><div><h3>Which fees should I enter?</h3><p>Add one-time title, registration and dealer documentation fees from your itemized quote. Enter each charge once. If an add-on is already included in the car price, do not add it again under fees. Recurring insurance, fuel and maintenance belong in your ownership budget.</p></div><div><h3>Sticker price or out-the-door price?</h3><p>Enter the vehicle price before tax and separate fees in the Car price field. The calculator adds those costs to show your out-the-door price before interest. If your quote already gives an out-the-door total, separate its components before entering them.</p></div></div>
  <p>Sales tax is calculated on the full car price, excluding fees. Local taxable fees, trade-in credits and rebate rules can change the actual bill. Confirm the itemized tax and fees with your seller or tax authority. This calculator does not infer your state’s rules.</p>
 </section>;
}
