"use client";
import { useState } from "react";
import type { LoanInput, LoanResult } from "@/lib/loan";

export function DownloadReport({ input, result, invalid }: { input: LoanInput; result: LoanResult; invalid: boolean }) {
  const [preparing, setPreparing] = useState(false);
  const [error, setError] = useState("");
  async function download() {
    setPreparing(true); setError("");
    try {
      const { createLoanPDF } = await import("@/lib/loan-pdf");
      const bytes = await createLoanPDF(input, result, invalid);
      const url = URL.createObjectURL(new Blob([new Uint8Array(bytes)], { type: "application/pdf" }));
      const anchor = document.createElement("a");
      anchor.href = url; anchor.download = `car-loan-report-${input.months}-months.pdf`;
      anchor.click();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
    } catch { setError("The PDF could not be prepared. Please try again or use Print estimate."); }
    finally { setPreparing(false); }
  }
  return <div><div className="flex flex-wrap gap-3">
    <button type="button" className="outline-button" onClick={download} disabled={preparing} aria-busy={preparing}>{preparing ? "Preparing PDF…" : "Download PDF"}</button>
    <button type="button" className="outline-button" onClick={() => window.print()}>Print estimate</button>
  </div><p role="status" className="text-sm" style={{ marginTop: error ? 8 : 0 }}>{error}</p></div>;
}
