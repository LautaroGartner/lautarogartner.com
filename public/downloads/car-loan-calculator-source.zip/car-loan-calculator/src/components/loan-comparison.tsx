import { calculateLoan, money, TERMS, type LoanInput, type LoanResult } from "@/lib/loan";

export function LoanComparison({ input, onSelect }: { input: LoanInput; onSelect: (months: number) => void }) {
  const loans = TERMS.map(months => calculateLoan({ ...input, months }));
  const metrics: { label: string; key: keyof Pick<LoanResult, "monthlyPayment" | "totalInterest" | "totalLoanPayments" | "totalPurchaseCost"> }[] = [
    { label: "Monthly payment", key: "monthlyPayment" },
    { label: "Total interest", key: "totalInterest" },
    { label: "Total loan payments", key: "totalLoanPayments" },
    { label: "Total purchase cost", key: "totalPurchaseCost" },
  ];
  return <section id="compare" className="comparison-section" aria-labelledby="compare-title">
    <div className="section-heading"><h2 id="compare-title">Find your balance.</h2>
      <p>A smaller payment can mean a bigger total. Compare the same car, down payment and annual interest rate.</p></div>
    <div className="table-scroll" role="region" aria-label="Loan term comparison; scroll horizontally for all five terms" tabIndex={0}>
      <table className="comparison-table">
        <caption className="sr-only">Comparison of 36, 48, 60, 72 and 84 month loans. Purchase cost includes the down payment. All figures in US dollars.</caption>
        <thead><tr><th scope="col">Loan term</th>{TERMS.map(months => <th key={months} scope="col" className={input.months === months ? "selected-col" : ""}>
          <button type="button" onClick={() => onSelect(months)} aria-label={`Use ${months} months`} aria-pressed={input.months === months}>
            <span>{months}</span> months <span className="term-check" aria-hidden="true">{input.months === months ? "Selected" : "Select term"}</span>
          </button>
        </th>)}</tr></thead>
        <tbody>{metrics.map(metric => <tr key={metric.key}><th scope="row">{metric.label}{metric.key === "totalPurchaseCost" && <small>Including down payment</small>}</th>
          {loans.map((loan, i) => <td key={TERMS[i]} className={input.months === TERMS[i] ? "selected-col" : ""}>{money(loan[metric.key])}</td>)}
        </tr>)}</tbody>
      </table>
    </div>
    <p className="table-note">Select a term to see its full breakdown. Your entered annual interest rate stays the same across terms.</p>
  </section>;
}
