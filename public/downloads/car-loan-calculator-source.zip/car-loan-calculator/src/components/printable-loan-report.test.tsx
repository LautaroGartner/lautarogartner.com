import { describe, expect, it } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { calculateLoan, EXAMPLE } from "@/lib/loan";
import { PrintableLoanReport } from "./printable-loan-report";

describe("complete printed loan report", () => {
  it.each([60, 84, 120])("prints all %i payments, independent of screen pagination", months => {
    const input = { ...EXAMPLE, months };
    const result = calculateLoan(input);
    const html = renderToStaticMarkup(<PrintableLoanReport input={input} result={result} invalid={false} />);
    const body = html.match(/<tbody>([\s\S]*?)<\/tbody>/)?.[1] ?? "";
    expect((body.match(/<tr>/g) ?? []).length).toBe(months);
    expect(body).toContain(`<th scope="row">${months}</th>`);
    expect(body).toContain("$0.00");
    expect(html).not.toContain("table-scroll");
    expect(html).not.toContain("Next 12 payments");
    if (months === 60) expect(html).toContain("$608.41");
  });
  it("explains a cash purchase without inventing repayment rows", () => {
    const input={...EXAMPLE,downPayment:35000};
    const html=renderToStaticMarkup(<PrintableLoanReport input={input} result={calculateLoan(input)} invalid={false} />);
    expect(html).toContain("No loan is required");
    expect(html).not.toContain("<tbody>");
    expect(html).toContain("$35,000.00");
  });
  it("explicitly identifies the last valid estimate when current form values are invalid", () => {
    const html=renderToStaticMarkup(<PrintableLoanReport input={EXAMPLE} result={calculateLoan(EXAMPLE)} invalid />);
    expect(html).toContain("Last valid estimate.");
    expect(html).toContain("valid inputs listed below");
    expect(html).toContain("$30,000.00");
  });
});
