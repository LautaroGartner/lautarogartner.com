import { money, type LoanInput, type LoanResult } from "@/lib/loan";

export function PrintableLoanReport({ input, result, invalid }: { input: LoanInput; result: LoanResult; invalid: boolean }) {
  return <article className="print-report" aria-labelledby="print-title">
    <header className="print-report-header"><p>The Real Cost of Your Car</p><h2 id="print-title">Car loan estimate</h2><p>{input.months}-month term · US dollars · Fixed annual interest rate</p></header>
    {invalid && <p className="print-notice"><strong>Last valid estimate.</strong> Some entries on the calculator need correction. This report uses the valid inputs listed below, matching the last valid estimate displayed on screen.</p>}
    <section className="print-overview"><div><h3>Purchase and loan inputs</h3><dl>
      <div><dt>Car price</dt><dd>{money(input.price)}</dd></div>
      <div><dt>Down payment</dt><dd>{money(input.downPayment)}</dd></div>
      <div><dt>Annual interest rate</dt><dd>{input.apr}%</dd></div>
      <div><dt>Loan term</dt><dd>{input.months} months</dd></div>
      <div><dt>Sales tax ({input.salesTax}%)</dt><dd>{money(result.taxAmount)}</dd></div>
      <div><dt>Purchase fees</dt><dd>{money(input.fees)}</dd></div>
      <div><dt>Tax and fees</dt><dd>{input.financeCosts === 1 ? "Financed" : "Paid upfront"}</dd></div>
    </dl></div><div><h3>Estimated costs</h3><dl>
      <div><dt>Regular monthly payment</dt><dd>{money(result.monthlyPayment)}</dd></div>
      <div><dt>Price + tax + fees</dt><dd>{money(result.purchaseSubtotal)}</dd></div>
      <div><dt>Cash at purchase</dt><dd>{money(input.downPayment + result.upfrontCosts)}</dd></div>
      <div><dt>Amount financed</dt><dd>{money(result.amountFinanced)}</dd></div>
      <div><dt>Total interest</dt><dd>{money(result.totalInterest)}</dd></div>
      <div><dt>Total loan payments</dt><dd>{money(result.totalLoanPayments)}</dd></div>
      <div className="print-purchase-total"><dt>Total purchase cost</dt><dd>{money(result.totalPurchaseCost)}</dd></div>
    </dl></div></section>
    <section className="print-assumptions"><h3>What this estimate includes</h3><p>Purchase cost includes all loan payments, the down payment and any tax and fees paid upfront. It excludes insurance, maintenance, depreciation, fuel and other ownership costs. Tax applies to the full car price, excluding fees. The entered annual interest rate is divided by 12; lender APR disclosures can include charges and differ from this rate. Interest is rounded monthly, and the final payment adjusts to clear the balance. Actual lender timing, rounding and tax rules may differ. This is an illustrative estimate, not a lender offer.</p></section>
    <section className="print-schedule"><h3>Complete amortization schedule</h3>
      {result.schedule.length ? <><p>{result.schedule.length} payments · Final payment: {money(result.schedule.at(-1)!.payment)} · Ending balance: {money(0)}</p>
      <table><caption>All monthly payments for this estimate</caption><thead><tr><th scope="col">Month</th><th scope="col">Payment</th><th scope="col">Principal</th><th scope="col">Interest</th><th scope="col">Remaining balance</th></tr></thead>
        <tbody>{result.schedule.map(row=><tr key={row.month}><th scope="row">{row.month}</th><td>{money(row.payment)}</td><td>{money(row.principal)}</td><td>{money(row.interest)}</td><td>{money(row.balance)}</td></tr>)}</tbody>
        <tfoot><tr><th scope="row">Totals</th><td>{money(result.totalLoanPayments)}</td><td>{money(result.amountFinanced)}</td><td>{money(result.totalInterest)}</td><td>{money(0)}</td></tr></tfoot>
      </table></> : <p>No loan is required. Your upfront payment covers the purchase, so there are no monthly repayments.</p>}
    </section>
    <footer className="print-report-footer">The Real Cost of Your Car · carcost.lautarogartner.com · Calculated on your device</footer>
  </article>;
}
