"use client";
import { useMemo, useState } from "react";
import { calculateLoan, EXAMPLE, money, validateLoan, type LoanInput } from "@/lib/loan";
import { LoanForm, type Draft } from "./loan-form";
import { CostSummary } from "./cost-summary";
import { PaymentChart } from "./payment-chart";
import { LoanComparison } from "./loan-comparison";
import { BudgetPlanner } from "./budget-planner";
import { PaymentSchedule } from "./payment-schedule";

const toDraft = (input: LoanInput) => Object.fromEntries(Object.entries(input).map(([key, value]) => [key, String(value)])) as Draft;
const toInput = (draft: Draft) => Object.fromEntries(Object.entries(draft).map(([key, value]) => [key, value.trim() === "" ? NaN : Number(value)])) as unknown as LoanInput;

export function Calculator() {
  const [draft, setDraft] = useState<Draft>(() => toDraft(EXAMPLE));
  const [input, setInput] = useState<LoanInput>(EXAMPLE);
  const errors = validateLoan(toInput(draft));
  const invalid = Object.keys(errors).length > 0;
  const result = useMemo(() => calculateLoan(input), [input]);
  const signature = Object.values(input).join("-");

  function change(key: keyof LoanInput, value: string) {
    const next = { ...draft, [key]: value };
    setDraft(next);
    const parsed = toInput(next);
    if (!Object.keys(validateLoan(parsed)).length) setInput(parsed);
  }
  function reset() { setDraft(toDraft(EXAMPLE)); setInput({ ...EXAMPLE }); }

  return <>
    <div id="calculator" className="calculator-grid" tabIndex={-1}>
      <LoanForm draft={draft} errors={errors} onChange={change} onReset={reset} />
      <div className="results-column min-w-0">
        <p className={`estimate-status ${invalid ? "has-error" : ""}`} role="status">
          {invalid ? "Showing the last valid estimate. Fix the highlighted inputs to update." : "Illustrative estimates · US dollars"}
        </p>
        <div aria-live="polite" aria-atomic="true" className="sr-only">{invalid ? "Inputs need attention." : `Estimated monthly payment ${money(result.monthlyPayment)}. Total purchase cost ${money(result.totalPurchaseCost)}.`}</div>
        <CostSummary input={input} result={result} />
        <PaymentChart key={signature} result={result} />
      </div>
    </div>
    <BudgetPlanner input={input} />
    <LoanComparison input={input} onSelect={months => change("months", String(months))} />
    <PaymentSchedule key={signature} input={input} result={result} />
    <section className="fine-print" aria-labelledby="notes-title">
      <h2 id="notes-title">A few things to know.</h2>
      <button type="button" className="print-estimate" onClick={()=>window.print()}>Print estimate</button>
      <div className="notes-grid">
        <p><strong>Purchase cost estimates.</strong> These estimates exclude insurance, maintenance, depreciation, fuel and other ownership costs. This calculator provides no lender quotes or offers.</p>
        <p><strong>How the numbers work.</strong> Amount financed = car price − down payment, plus any financed taxes and fees. Total loan payments = principal + interest. Total purchase cost = total loan payments + down payment + any taxes and fees paid upfront.</p>
        <p><strong>Simple assumptions. Clear estimates.</strong> APR is treated as a fixed annual interest rate divided by 12. Payments are monthly and on time. Interest is rounded to cents each month; the final payment adjusts to clear the balance. Actual lender APR may include charges, and tax rules vary by location.</p>
      </div>
      <details><summary>See the calculation</summary><div className="formula"><p>Monthly payment = P × r ÷ (1 − (1 + r)<sup>−n</sup>), where P is the amount financed, r = APR ÷ 100 ÷ 12, and n is the number of months. At 0% APR, payment = P ÷ n.</p>
        <p>Current price + tax + fees: {money(input.price)} + {money(result.taxAmount)} + {money(input.fees)} = {money(result.purchaseSubtotal)}. Subtract {money(input.downPayment)} down and {money(result.upfrontCosts)} in costs paid upfront to finance {money(result.amountFinanced)}.</p>
        <p>The preset is illustrative: a $35,000 car, $5,000 down, 8% APR and 60 months, with no taxes or fees. Learn about <a href="https://www.consumerfinance.gov/ask-cfpb/how-do-i-compare-auto-loan-offers-what-should-i-look-at-besides-the-monthly-payment-en-753/" target="_blank" rel="noreferrer">comparing auto loans from the CFPB<span className="sr-only"> (opens in a new tab)</span></a>.</p>
      </div></details>
    </section>
  </>;
}
