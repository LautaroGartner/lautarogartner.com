"use client";
import { useState } from "react";
import { money, scheduleCSV, type LoanInput, type LoanResult } from "@/lib/loan";

export function PaymentSchedule({ result, input }: { result: LoanResult; input: LoanInput }) {
  const [page, setPage] = useState(0);
  const pageCount = Math.ceil(result.schedule.length / 12);
  const currentPage = Math.min(page, Math.max(0, pageCount - 1));
  const rows = result.schedule.slice(currentPage * 12, currentPage * 12 + 12);
  function download() {
    const url = URL.createObjectURL(new Blob([scheduleCSV(result.schedule)], { type: "text/csv;charset=utf-8;" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `car-loan-${input.months}-months.csv`;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  return <section id="schedule" className="schedule-section" aria-labelledby="schedule-title">
    <div className="section-heading flex flex-wrap items-end justify-between gap-5">
      <div><h2 id="schedule-title">Your payment schedule.</h2><p>Follow every dollar, from the first payment to the last.</p></div>
      <button type="button" className="outline-button" disabled={!result.schedule.length} onClick={download}>
        <svg aria-hidden="true" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M12 3v12m-4-4 4 4 4-4M5 16v4h14v-4" strokeLinecap="round" strokeLinejoin="round" /></svg>
        Download CSV
      </button>
    </div>
    {rows.length ? <>
      <div className="table-scroll" role="region" aria-label="Monthly amortization schedule; scroll horizontally if needed" tabIndex={0}>
        <table className="schedule-table">
          <caption className="sr-only">Monthly amortization schedule in US dollars, {input.months} month term at {input.apr}% APR.</caption>
          <thead><tr>{["Month", "Payment", "Principal", "Interest", "Remaining balance"].map(label => <th key={label} scope="col">{label}</th>)}</tr></thead>
          <tbody>{rows.map(row => <tr key={row.month}><th scope="row">{row.month.toString().padStart(2, "0")}</th>
            <td>{money(row.payment)}</td><td>{money(row.principal)}</td><td>{money(row.interest)}</td><td>{money(row.balance)}</td></tr>)}</tbody>
          <tfoot><tr><th scope="row">Loan totals</th><td>{money(result.totalLoanPayments)}</td><td>{money(result.amountFinanced)}</td><td>{money(result.totalInterest)}</td><td>{money(0)}</td></tr></tfoot>
        </table>
      </div>
      <div className="pagination flex flex-wrap items-center justify-between gap-4">
        <p aria-live="polite">Months {rows[0].month}–{rows.at(-1)?.month} of {result.schedule.length}</p>
        <div className="flex items-center gap-4"><button type="button" className="page-button" disabled={currentPage === 0} onClick={() => setPage(p => Math.max(0, p - 1))} aria-label="Previous 12 payments">Previous</button>
          <span>{currentPage + 1} / {pageCount}</span>
          <button type="button" className="page-button" disabled={currentPage + 1 >= pageCount} onClick={() => setPage(p => p + 1)} aria-label="Next 12 payments">Next</button></div>
      </div>
    </> : <p className="cash-message">Your down payment covers the full purchase. There is no loan to repay.</p>}
  </section>;
}
