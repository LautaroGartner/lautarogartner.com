"use client";

import { useState } from "react";
import { money, type LoanResult } from "@/lib/loan";

export function PaymentChart({ result }: { result: LoanResult }) {
  const [selected, setSelected] = useState(0);
  const rows = result.schedule;
  const active = rows[Math.min(selected, rows.length - 1)];
  const ceiling = Math.max(result.monthlyPayment, ...rows.map(row => row.payment), 1);
  const axisMoney = (n: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);

  return <section className="chart-section" aria-labelledby="chart-title">
    <div className="chart-heading flex flex-wrap items-center justify-between gap-3">
      <h2 id="chart-title">Every payment.<br className="chart-break" /> Broken down.</h2>
      <div className="chart-legend flex gap-5 text-xs"><span><i className="dot principal-dot" />Principal</span><span><i className="dot interest-dot" />Interest</span></div>
    </div>
    {active ? <>
      <div className="chart-container">
        <div className="y-axis" aria-hidden="true"><span>{axisMoney(ceiling)}</span><span>{axisMoney(ceiling / 2)}</span><span>$0</span></div>
        <div className="plot">
          <div className="grid-line top" /><div className="grid-line middle" /><div className="grid-line bottom" />
          <svg viewBox="0 0 1000 160" preserveAspectRatio="none" role="img"
            aria-label="Monthly principal and interest payments. Use the month slider below to explore exact amounts."
            onPointerMove={e => {
              const rect = e.currentTarget.getBoundingClientRect();
              setSelected(Math.min(rows.length - 1, Math.max(0, Math.floor((e.clientX - rect.left) / rect.width * rows.length))));
            }}>
            {rows.map((row, i) => {
              const width = 1000 / rows.length;
              const p = row.principal / ceiling * 150;
              const interest = row.interest / ceiling * 150;
              return <g key={row.month} opacity={i === selected ? 1 : .8}>
                <rect x={i * width + 1} y={160 - p - interest} width={Math.max(width - 3, 1)} height={interest} fill="#626268" rx="1.5" />
                <rect x={i * width + 1} y={160 - p} width={Math.max(width - 3, 1)} height={p} fill={i === selected ? "#f5f5f7" : "#c8c8ce"} rx="1.5" />
              </g>;
            })}
          </svg>
          <div className="x-axis" aria-hidden="true"><span>Month 1</span><span>{Math.ceil(rows.length / 2)}</span><span>{rows.length}</span></div>
        </div>
      </div>
      <div className="chart-inspector">
        <div className="month-control"><label htmlFor="chart-month">Month {active.month}</label>
          <input id="chart-month" type="range" min={1} max={rows.length} value={active.month}
            onChange={e => setSelected(Number(e.target.value) - 1)} aria-label="Explore payment month"
            aria-valuetext={`Month ${active.month}: ${money(active.principal)} principal, ${money(active.interest)} interest`} />
        </div>
        <p aria-live="polite" aria-atomic="true"><span>Principal <b>{money(active.principal)}</b></span><span>Interest <b>{money(active.interest)}</b></span></p>
      </div>
    </> : <div className="no-loan"><p>All paid up.</p><span>No loan means no monthly payments or interest.</span></div>}
  </section>;
}
