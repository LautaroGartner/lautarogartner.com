"use client";
import { useState } from "react";
import { money, priceForBudget, type LoanInput } from "@/lib/loan";
export function BudgetPlanner({ input }: { input: LoanInput }) {
  const [budget, setBudget] = useState("600");
  const amount = budget.trim() === "" ? NaN : Number(budget);
  const valid = Number.isFinite(amount) && amount >= 0 && amount <= 1_000_000;
  return <section className="budget-planner panel" aria-labelledby="budget-title">
    <div><h2 id="budget-title">Start with your monthly budget.</h2><p>Estimate a car price using your current down payment, rate, term, tax and fees.</p></div>
    <div className="budget-controls"><div className="field"><label htmlFor="monthly-budget">Target monthly payment</label><div className="input-wrap"><span aria-hidden="true">$</span><input id="monthly-budget" type="number" inputMode="decimal" min="0" max="1000000" step="1" value={budget} onChange={e=>setBudget(e.target.value)} aria-invalid={!valid} aria-describedby="budget-note" /></div></div>
    <div className="budget-result" aria-live="polite"><span>Estimated maximum car price</span><strong>{valid ? money(priceForBudget(amount,input)) : "—"}</strong></div></div>
    <p id="budget-note" className="table-note">{valid ? `Planning estimate for ${input.months} months at ${input.apr}%. ${input.financeCosts === 0 ? "Allow extra cash for taxes and fees upfront." : "Taxes and fees are included."} Insurance, maintenance, fuel and other ownership costs need a separate budget. This is not loan approval.` : "Enter a monthly budget between $0 and $1,000,000."}</p>
  </section>;
}
