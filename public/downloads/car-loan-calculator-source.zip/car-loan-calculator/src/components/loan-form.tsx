import { TERMS, type LoanErrors, type LoanInput } from "@/lib/loan";

export type Draft = Record<keyof LoanInput, string>;

interface Props {
  draft: Draft;
  errors: LoanErrors;
  onChange: (key: keyof LoanInput, value: string) => void;
  onReset: () => void;
}

export function LoanForm({ draft, errors, onChange, onReset }: Props) {
  const field = (key: keyof LoanInput, label: string, unit: string, max: number, step = "0.01") => (
    <div className="field">
      <label htmlFor={key}>{label}</label>
      <div className={`input-wrap ${errors[key] ? "invalid" : ""}`}>
        {unit === "$" && <span aria-hidden="true">$</span>}
        <input id={key} name={key} type="number" inputMode={key === "months" ? "numeric" : "decimal"}
          min={key === "months" ? 1 : 0} max={max} step={step} value={draft[key]}
          onChange={e => onChange(key, e.target.value)}
          aria-invalid={!!errors[key]} aria-describedby={errors[key] ? `${key}-error` : undefined} />
        {unit !== "$" && <span aria-hidden="true">{unit}</span>}
      </div>
      {errors[key] && <p className="field-error" id={`${key}-error`}>{errors[key]}</p>}
    </div>
  );

  return <section className="input-panel panel" aria-labelledby="inputs-title">
    <div className="panel-heading flex items-center justify-between gap-3">
      <h2 id="inputs-title">Your car. Your numbers.</h2>
      <button type="button" className="text-button reset" onClick={onReset}>Reset example</button>
    </div>
    <form onSubmit={e => e.preventDefault()} noValidate className="flex flex-col gap-5">
      <div className="grid grid-cols-2 gap-4">
        {field("price", "Car price", "$", 10_000_000)}
        {field("downPayment", "Down payment", "$", 30_000_000)}
      </div>
      {field("apr", "APR", "%", 100, "0.01")}
      <fieldset>
        <legend>Loan term <span className="muted">in months</span></legend>
        <div className="term-segments" aria-label="Common loan terms">
          {TERMS.map(months => <button key={months} type="button" aria-pressed={Number(draft.months) === months}
            onClick={() => onChange("months", String(months))}>{months}</button>)}
        </div>
        <div className="custom-term">
          <label htmlFor="months">Custom term (months)</label>
          <div className={`input-wrap ${errors.months ? "invalid" : ""}`}>
            <input id="months" type="number" inputMode="numeric" min={1} max={120} step={1} value={draft.months}
              onChange={e => onChange("months", e.target.value)} aria-invalid={!!errors.months}
              aria-describedby={errors.months ? "months-error" : "term-hint"} />
            <span aria-hidden="true">mo</span>
          </div>
        </div>
        {errors.months ? <p className="field-error" id="months-error">{errors.months}</p>
          : <span className="sr-only" id="term-hint">Enter 1 to 120 months.</span>}
      </fieldset>
      <div className="grid grid-cols-2 gap-4">
        {field("salesTax", "Sales tax", "%", 100)}
        {field("fees", "Fees", "$", 10_000_000)}
      </div>
    </form>
    <p className="input-note">Taxes and fees are financed.<br />Sales tax applies to the full car price.</p>
  </section>;
}
