import { money, type LoanInput, type LoanResult } from "@/lib/loan";

export function CostSummary({ input, result }: { input: LoanInput; result: LoanResult }) {
  const share = result.totalLoanPayments > 0 ? result.amountFinanced / result.totalLoanPayments * 100 : 0;
  return <section className="summary-panel panel" aria-labelledby="estimate-title">
    <div className="payment-hero">
      <h2 id="estimate-title">Estimated monthly payment</h2>
      <p className={`payment-value ${money(result.monthlyPayment).length > 10 ? "compact-number" : ""}`} data-testid="monthly-payment">{money(result.monthlyPayment)}<span>/mo</span></p>
      <p className="payment-term">{input.months} months at {input.apr}% APR</p>
    </div>
    <div className="cost-details">
      <dl>
        <div><dt>Amount financed</dt><dd>{money(result.amountFinanced)}</dd></div>
        <div><dt>Total interest</dt><dd data-testid="total-interest">{money(result.totalInterest)}</dd></div>
        <div><dt>Total loan payments</dt><dd>{money(result.totalLoanPayments)}</dd></div>
      </dl>
      {result.upfrontCosts > 0 && <dl><div><dt>Taxes &amp; fees paid upfront</dt><dd>{money(result.upfrontCosts)}</dd></div></dl>}
      <div className="purchase-total">
        <div><h3>Total purchase cost</h3><p>Including {money(input.downPayment)} down{result.upfrontCosts > 0 ? " + upfront costs" : ""}</p></div>
        <strong data-testid="purchase-cost">{money(result.totalPurchaseCost)}</strong>
      </div>
    </div>
    <div className="summary-distribution">
      <div className="cost-bar" aria-hidden="true"><span style={{ width: `${share}%` }} /></div>
      <div className="bar-legend flex flex-wrap items-center justify-between gap-2">
        <span><i className="dot principal-dot" />Principal <b>{share.toFixed(1)}%</b></span>
        <span><i className="dot interest-dot" />Interest <b>{result.totalLoanPayments > 0 ? (100 - share).toFixed(1) : "0.0"}%</b></span>
      </div>
    </div>
  </section>;
}
